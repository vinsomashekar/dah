#
# Copyright 2013-2016 Digital Asset Holdings, LLC.
# Confidential, Proprietary, and/or the subject matter herein may be
# protected under Patent law.  All rights reserved.
#

AWS_ENV = dict(
    PROCESSING_NODE_EC2_NAME = 'processing-node',
    SIGNING_SERVER_EC2_NAME = 'signing-server',
    DB_SERVER_EC2_NAME = 'db',
    MQ_SERVER_EC2_NAME = 'mq',
    CLUSTER_NAME = 'dah-aws-demo',
    key_filename = '~/.ssh/dah-demo.pem'
)

PORTS = dict(
    DB_PORT = 5433,
    RABBIT_PORT = 5672,
    PROCESSING_NODE_PORT = 8080,
    SIGNING_SERVER_PORT = 8090
)

DB_ENV = dict(
    DB_USERNAME = 'da',
    DB_PASSWORD = 'da',
    DB_NAME = 'metadb'
)


TP1_ACCOUNTS = [{'legalName': 'TP1', 'parentLegalName': '', 'type': 'DEALER'},
                {'legalName': 'Issuer', 'parentLegalName': 'TP1', 'type': 'ISSUER'},
                {'legalName': 'Lender', 'parentLegalName': 'TP1', 'type': 'CUSTOMER'}]

CP1_ACCOUNTS = [{'legalName': 'CP1', 'parentLegalName': '', 'type': 'CLEARING'}]

CP2_ACCOUNTS = [{'legalName': 'CP2', 'parentLegalName': '', 'type': 'CLEARING'}]

CCP_ACCOUNTS = [{'legalName': 'CCP', 'parentLegalName': '', 'type': 'CCP'}]

TP2_ACCOUNTS = [{'legalName': 'TP2', 'parentLegalName': '', 'type': 'DEALER'},
                {'legalName': 'Buyer', 'parentLegalName': 'TP2', 'type': 'CUSTOMER'},
                {'legalName': 'Borrower', 'parentLegalName': 'TP2', 'type': 'CUSTOMER'}]

SP1_ACCOUNTS = [{'legalName': 'SP1', 'parentLegalName': '', 'type': 'CUSTODIAN'},
                {'legalName': 'CCP Settle', 'parentLegalName': 'SP1', 'type': 'SETTLE'},
                {'legalName': 'CCP Open Settle', 'parentLegalName': 'CCP Settle', 'type': 'OPEN'},
                {'legalName': 'CCP Commit Settle', 'parentLegalName': 'CCP Settle', 'type': 'COMMIT'},
                {'legalName': 'CP1 Settle', 'parentLegalName': 'SP1', 'type': 'SETTLE'},
                {'legalName': 'CP1 Open Settle', 'parentLegalName': 'CP1 Settle', 'type': 'OPEN'},
                {'legalName': 'CP1 Commit Settle', 'parentLegalName': 'CP1 Settle', 'type': 'COMMIT'},
                {'legalName': 'TP1 Settle', 'parentLegalName': 'SP1', 'type': 'SETTLE'},
                {'legalName': 'TP1 Open Settle', 'parentLegalName': 'TP1 Settle', 'type': 'OPEN'},
                {'legalName': 'TP1 Commit Settle', 'parentLegalName': 'TP1 Settle', 'type': 'COMMIT'},
                {'legalName': 'Issuer Settle', 'parentLegalName': 'SP1', 'type': 'SETTLE'},
                {'legalName': 'Issuer Open Settle', 'parentLegalName': 'Issuer Settle', 'type': 'OPEN'},
                {'legalName': 'Issuer Commit Settle', 'parentLegalName': 'Issuer Settle', 'type': 'COMMIT'},
                {'legalName': 'Lender Settle', 'parentLegalName': 'SP1', 'type': 'SETTLE'},
                {'legalName': 'Lender Open Settle', 'parentLegalName': 'Lender Settle', 'type': 'OPEN'},
                {'legalName': 'Lender Commit Settle', 'parentLegalName': 'Lender Settle', 'type': 'COMMIT'}]

SP2_ACCOUNTS = [{'legalName': 'SP2', 'parentLegalName': '', 'type': 'CUSTODIAN'},
                {'legalName': 'CP2 Settle', 'parentLegalName': 'SP2', 'type': 'SETTLE'},
                {'legalName': 'CP2 Open Settle', 'parentLegalName': 'CP2 Settle', 'type': 'OPEN'},
                {'legalName': 'CP2 Commit Settle', 'parentLegalName': 'CP2 Settle', 'type': 'COMMIT'},
                {'legalName': 'TP2 Settle', 'parentLegalName': 'SP2', 'type': 'SETTLE'},
                {'legalName': 'TP2 Open Settle', 'parentLegalName': 'TP2 Settle', 'type': 'OPEN'},
                {'legalName': 'TP2 Commit Settle', 'parentLegalName': 'TP2 Settle', 'type': 'COMMIT'},
                {'legalName': 'Buyer Settle', 'parentLegalName': 'SP2', 'type': 'SETTLE'},
                {'legalName': 'Buyer Open Settle', 'parentLegalName': 'Buyer Settle', 'type': 'OPEN'},
                {'legalName': 'Buyer Commit Settle', 'parentLegalName': 'Buyer Settle', 'type': 'COMMIT'},
                {'legalName': 'Borrower Settle', 'parentLegalName': 'SP2', 'type': 'SETTLE'},
                {'legalName': 'Borrower Open Settle', 'parentLegalName': 'Borrower Settle', 'type': 'OPEN'},
                {'legalName': 'Borrower Commit Settle', 'parentLegalName': 'Borrower Settle', 'type': 'COMMIT'}]

TP1_CUSTOMER_ACCOUNTS = [{'legalName': 'TP1 Customer', 'parentLegalName': 'TP1', 'type': 'CUSTOMER'},
                         {'legalName': 'TP1 Customer Settle', 'parentLegalName': 'SP1', 'type': 'SETTLE'},
                         {'legalName': 'TP1 Customer Open Settle', 'parentLegalName': 'TP1 Settle', 'type': 'OPEN'},
                         {'legalName': 'TP1 Customer Commit Settle', 'parentLegalName': 'TP1 Settle', 'type': 'COMMIT'}
                         ]

TP2_CUSTOMER_ACCOUNTS = [{'legalName': 'TP2 Customer', 'parentLegalName': 'TP2', 'type': 'CUSTOMER'},
                         {'legalName': 'TP2 Customer Settle', 'parentLegalName': 'SP2', 'type': 'SETTLE'},
                         {'legalName': 'TP2 Customer Open Settle', 'parentLegalName': 'TP2 Settle', 'type': 'OPEN'},
                         {'legalName': 'TP2 Customer Commit Settle', 'parentLegalName': 'TP2 Settle', 'type': 'COMMIT'}
                         ]

ISSUER_REGISTRY_ACCOUNTS = [{'legalName': 'Issuer Registry', 'parentLegalName': '', 'type': 'NONE'},
                            {'legalName': 'I9876500001', 'parentLegalName': 'Issuer Registry', 'type': 'NONE'},
                            {'legalName': 'I9876500002', 'parentLegalName': 'Issuer Registry', 'type': 'NONE'},
                            {'legalName': 'I9876500003', 'parentLegalName': 'Issuer Registry', 'type': 'NONE'}]


ACCOUNTS = TP1_ACCOUNTS + CP1_ACCOUNTS + SP1_ACCOUNTS + TP2_ACCOUNTS + CP2_ACCOUNTS + SP2_ACCOUNTS + ISSUER_REGISTRY_ACCOUNTS + CCP_ACCOUNTS + TP1_CUSTOMER_ACCOUNTS + TP2_CUSTOMER_ACCOUNTS
