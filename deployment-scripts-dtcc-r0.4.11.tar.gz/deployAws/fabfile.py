#
# Copyright 2013-2016 Digital Asset Holdings, LLC.
# Confidential, Proprietary, and/or the subject matter herein may be
# protected under Patent law.  All rights reserved.
#

import time
import json
import requests
from fabric.api import *

import boto3
from parameters import *

from faker import Factory

@task
def awsLocal(regionName='us-east-1'):
    aws(regionName)
    env.tradePlatformHostHTTP = env.tradePlatformHostPublic
    env.signingServerHostHTTP = env.signingServerHostPublic

@task
def awsRemote(regionName='us-east-1'):
    aws(regionName)
    env.tradePlatformHostHTTP = env.tradePlatformHostPrivate
    env.signingServerHostHTTP = env.signingServerHostPrivate

def aws(regionName='us-east-1', processingNodeImageName=''):
    env.user = 'ec2-user'
    env.update(AWS_ENV)
    machines = get_aws_machine_properties(regionName)

    env.rabbitHostPrivate = machines[env.MQ_SERVER_EC2_NAME].private_ip_address
    env.tradePlatformHostPrivate = machines[env.PROCESSING_NODE_EC2_NAME].private_ip_address
    env.signingServerHostPrivate = machines[env.SIGNING_SERVER_EC2_NAME].private_ip_address
    env.dbHostPrivate = machines[env.DB_SERVER_EC2_NAME].private_ip_address

    env.rabbitHostPublic = machines[env.MQ_SERVER_EC2_NAME].public_ip_address
    env.tradePlatformHostPublic = machines[env.PROCESSING_NODE_EC2_NAME].public_ip_address
    env.signingServerHostPublic = machines[env.SIGNING_SERVER_EC2_NAME].public_ip_address
    env.dbHostPublic = machines[env.DB_SERVER_EC2_NAME].public_ip_address

    env.roledefs.update({
        'processingNode': [env.tradePlatformHostPublic],
        'signingServer': [env.signingServerHostPublic],
        'mq': [env.rabbitHostPublic],
        'db': [env.dbHostPublic]
    })
    env.processingNodeImageName = processingNodeImageName or env.PROCESSING_NODE_EC2_NAME
    env.update(PORTS)



def get_aws_machine_properties(regionName):
    ec2 = boto3.resource('ec2', regionName)
    filters = [{"Name": 'tag:Node Cluster Name', 'Values': [env.CLUSTER_NAME]}]
    instances = ec2.instances.filter(Filters=filters)
    machines = {}
    for instance in instances:
        machines.update({tag['Value']: instance for tag in instance.tags if tag['Key'] == 'Name'})
    return machines


@task
def deployDemo(build, dockerRepo='digitalasset'):
    env.dockerRepo = dockerRepo
    startDemoEnvironment(build)
    print 'sleeping after starting trade-platform'
    time.sleep(10)
    prepareSecuritiesDemo()


@task
def startPerfEnv(build, dockerRepo='digitalasset'):
    env.dockerRepo = dockerRepo
    env.build = build
    execute(stopAllEnv)
    execute(startMq)
    time.sleep(5)
    execute(startDb)
    time.sleep(5)
    execute(startSigningServer, env.build)


@task
@roles('processingNode')
def runPerfTest(accounts, trades, assets):
    command = "sh perfTestInDocker.sh {0} {1} {2} {3} {4} {5} {6}" \
        .format(env.dbHostPrivate, env.DB_PORT, accounts, trades, assets, accounts, assets)
    run('docker run -i -t {0}/{1}:{2} {3}'.format(env.dockerRepo, env.processingNodeImageName, env.build, command))


def startDemoEnvironment(build):
    execute(stopAllEnv)
    execute(startMq)
    time.sleep(5)
    execute(startDb)
    time.sleep(5)
    execute(startProcessingNode, build)
    ensureServerIsUp('processing-node', "http://%s:%s/" % (env.tradePlatformHostHTTP, env.PROCESSING_NODE_PORT))
    time.sleep(5)
    execute(startSigningServer, build)
    ensureServerIsUp('sign-server', "http://%s:%s/api/status" % (env.signingServerHostHTTP, env.SIGNING_SERVER_PORT))

def ensureServerIsUp(name, url, delayAfter=10):
    for i in range(60):
        try:
            print "(%s) Checking if %s server is up on %s" % (i, name, url)
            res = requests.get(url, timeout=1)
            res.raise_for_status()
            print "It is up. Continuing..."
            time.sleep(delayAfter)
            return
        except requests.exceptions.HTTPError as e:
            print "HTTP request returned a bas status code"
            raise e
        except:
            print "It is not up yet. Trying again..."
            time.sleep(1)
    raise Exception('Took more than 60 seconds. Giving up on {}'.format(url))

def tp1AccountsToIssueUSDTo(limit):
    allLegalNames = map(lambda a : a['legalName'], ACCOUNTS)
    mustInclude = ['TP1', 'CP1', 'CCP']
    otherAccounts = filter(lambda legalName: legalName not in mustInclude and
                                             'TP1' in legalName and
                                             'Settle' not in legalName and
                                             'Customer' not in legalName and
                                             'Issuer' not in legalName and
                                             'SP' not in legalName and
                                             '{} Settle'.format(legalName) in allLegalNames,
                           allLegalNames)
    return mustInclude + otherAccounts[:(limit-len(mustInclude))]


def tp2AccountsToIssueUSDTo(limit):
    allLegalNames = map(lambda a : a['legalName'], ACCOUNTS)
    mustInclude = ['TP2', 'CP2']
    otherAccounts = filter(lambda legalName: legalName not in mustInclude and
                                             'TP2' in legalName and
                                             'Settle' not in legalName and
                                             'Customer' not in legalName and
                                             'Issuer' not in legalName and
                                             'SP' not in legalName and
                                             '{} Settle'.format(legalName) in allLegalNames,
                           allLegalNames)
    return mustInclude + otherAccounts[:(limit-len(mustInclude))]

def tp1AccountsToIssueXYZTo(limit):
    allLegalNames = map(lambda a : a['legalName'], ACCOUNTS)
    mustInclude = ['Lender']
    otherAccounts = filter(lambda legalName: legalName not in mustInclude and
                                             'TP1-' in legalName and # dash is so that it will be a customer
                                             'Settle' not in legalName and
                                             'Customer' not in legalName and
                                             'Issuer' not in legalName and
                                             'SP' not in legalName and
                                             '{} Settle'.format(legalName) in allLegalNames,
                           allLegalNames)
    return mustInclude + otherAccounts[:(limit-len(mustInclude))]

def tp2AccountsToIssueXYZTo(limit):
    allLegalNames = map(lambda a : a['legalName'], ACCOUNTS)
    mustInclude = []
    otherAccounts = filter(lambda legalName: legalName not in mustInclude and
                                             'TP2-' in legalName and # dash is so that it will be a customer
                                             'Settle' not in legalName and
                                             'Customer' not in legalName and
                                             'Issuer' not in legalName and
                                             'SP' not in legalName and
                                             '{} Settle'.format(legalName) in allLegalNames,
                           allLegalNames)
    return mustInclude + otherAccounts[:(limit-len(mustInclude))]


def prepareSecuritiesDemo():
    host = env.tradePlatformHostHTTP
    port = env.PROCESSING_NODE_PORT

    addAccounts()
    execute(acceptAllPendingRegistrations, host, port, host='localhost')

    time.sleep(2)

    execute(issueAsset, host, port, issuer='CCP', asset='USD', amount=1000000)
    execute(signTransactions)

    time.sleep(2)

    print 'commit USD'
    execute(commitAsset, host, port, name='CCP', asset='USD', amount=1000000)
    execute(signTransactions)

    time.sleep(2)

    print 'distributing USD'
    issueUSDTo = tp1AccountsToIssueUSDTo(10) + tp2AccountsToIssueUSDTo(10)
    amountPerAccount = 1000000 / len(issueUSDTo)
    print 'distributing USD to {} accounts, {} USD each'.format(len(issueUSDTo), amountPerAccount)
    for account in issueUSDTo:
        execute(distributeAsset, host, port, issuer='CCP', asset='USD', amount=amountPerAccount,
                account=account)
        execute(signTransactions)
        time.sleep(1)

    time.sleep(2)

    print 'issue XYZ'
    execute(issueAsset, host, port, issuer='Issuer', asset='$XYZ', amount=100000)
    execute(signTransactions)

    time.sleep(2)

    print 'commit XYZ'
    execute(commitAsset, host, port, name='Issuer', asset='$XYZ', amount=40000)
    execute(signTransactions)

    time.sleep(2)

    print 'distributing XYZ'
    issueXYZTo = tp1AccountsToIssueXYZTo(5) + tp2AccountsToIssueXYZTo(5)
    amountPerAccount = 40000 / len(issueXYZTo)
    for account in issueXYZTo:
        execute(distributeAsset, host, port, issuer='Issuer', asset='$XYZ', amount=amountPerAccount, account=account)
        execute(signTransactions)
        time.sleep(1)


def distributeAssetToAccounts(host, port, accounts, issuer, asset, amount):
    amountPerAccount = amount / len(accounts)
    for account in accounts:
        execute(distributeAsset, host, port, issuer=issuer, asset=asset, amount=amountPerAccount,
                account=account, hosts='localhost')
        execute(signTransactions)

        time.sleep(2)


def addAccounts():
    for account in ACCOUNTS:
        execute(addAccount, account['legalName'], account['parentLegalName'], account['type'], env.signingServerHostHTTP, env.SIGNING_SERVER_PORT, hosts='localhost')


def addAccount(legalName, parentLegalName, type, host, port):
    print 'Adding account %s' % legalName
    parent = '' if parentLegalName is None else parentLegalName
    fake = Factory.create('en_US')
    data = {
        'id': legalName,
        'parentId': parent,
        'name': legalName,
        'type': type,
        'address': {
            'line1': fake.street_address(),
            'line2': '',
            'line3': '',
            'postcode': fake.zipcode(),
            'country': fake.country_code()
        }
    }
    requests.post('http://%s:%s/api/accounts' % (host, port), json=data, timeout=5)

def acceptAllPendingRegistrations(host, port):
    response = json.loads(requests.get('http://%s:%s/api/registration' % (host, port)).text)
    for registration in response['pending']:
        res = requests.put('http://%s:%s/api/registration/%s' % (host, port, registration['accountId']), timeout=5)
        res.raise_for_status()

def issueAsset(host, port, issuer, asset, amount):
    res = requests.post("http://%s:%s/api/trade/issuer/%s/asset/%s/issue" % (host, port , issuer, asset), json = amount, timeout=5)
    res.raise_for_status()

def signTransactions(timeoutInSeconds = 10):
    port = env.SIGNING_SERVER_PORT
    host = env.signingServerHostHTTP
    start = time.time()
    pendingTransactions = getPendingSignatureTransactionsFromSigningServer(host, port)

    while (len(pendingTransactions) == 0 and time.time() - start < timeoutInSeconds):
        pendingTransactions = getPendingSignatureTransactionsFromSigningServer(host, port)
    for txId in pendingTransactions.keys():
        signTransaction(host, port, txId)

def getPendingSignatureTransactionsFromSigningServer(host, port):
    request = requests.get('http://%s:%s/api/%s' % (host, port, 'transactions'), timeout=5)
    request.raise_for_status()
    return json.loads(request.text)

def signTransaction(host, port, transactionId):
    res = requests.put('http://%s:%s/api/%s/%s' % (host, port, 'sign', transactionId), timeout=5)
    res.raise_for_status()
    return res

def commitAsset(host, port, name, asset, amount):
    data = { 'legalName': name, 'assetName': asset, 'amount': amount }
    res = requests.post('http://%s:%s/api/settle/commit' % (host, port), json = data, timeout=5)
    res.raise_for_status()
    return res

def distributeAsset(host, port, issuer, asset, amount, account):
    data = {account: amount}
    res = requests.post('http://%s:%s/api/trade/issuer/%s/asset/%s/distribute' % (host, port, issuer, asset), json = data, timeout=5)
    res.raise_for_status()

@roles('processingNode')
def startProcessingNode(build):
    run('docker run --detach=true \
         --log-opt max-size=100m \
         --log-opt max-file=5 \
         --publish %(tradePlatformPort)s:8080 \
         -e MQ_HOST_PORT_5672_TCP_ADDR=%(rabbitHost)s \
         -e MQ_HOST_PORT_5672_TCP_PORT=%(rabbitPort)s\
         -e METADB_HOST=%(dbHost)s \
         -e METADB_PORT=%(dbPort)s \
         --name=trade-platform \
         %(dockerRepo)s/%(imageName)s:%(build)s'
            % {'build': build,
               'rabbitHost': env.rabbitHostPrivate,
               'rabbitPort': env.RABBIT_PORT,
               'dbHost': env.dbHostPrivate,
               'dbPort': env.DB_PORT,
               'tradePlatformPort': env.PROCESSING_NODE_PORT,
               'dockerRepo': env.dockerRepo,
               'imageName': env.processingNodeImageName
               })

@roles('processingNode', 'signingServer', 'mq', 'db')
@parallel
def stopAllEnv():
    run("docker ps -a -q | xargs --no-run-if-empty docker rm -f", warn_only=True)

@roles('mq')
def startMq():
    run('docker run \
        --log-opt max-size=100m \
        --log-opt max-file=5 \
        --detach=true \
        --name=rabbit \
        --hostname=rabbit \
        --publish 5672:5672 \
        --publish 15672:15672 \
        rabbitmq:3.5.3-management')

@roles('db')
def startDb():
    DB_CONTAINER_NAME = 'db'
    env.update(DB_ENV)
    CONF_FILE_NAME = 'postgresql.conf'
    CONF_FILE_DEST_PATH = '~/%s' % CONF_FILE_NAME
    put(CONF_FILE_NAME, CONF_FILE_DEST_PATH, use_sudo=True)
    run('docker run \
    --log-opt max-size=100m \
    --log-opt max-file=5 \
    --detach=true \
    --name=%(containerName)s \
    --hostname=db \
    --publish %(dbPort)s:5432 \
    -e POSTGRES_USER=%(user)s \
    -e POSTGRES_PASSWORD=%(password)s \
    -e POSTGRES_DB=%(dbName)s \
    postgres:9.4' \
        %{'user': env.DB_USERNAME,
          'password': env.DB_PASSWORD,
          'dbName': env.DB_NAME,
          'dbPort': env.DB_PORT,
          'containerName': DB_CONTAINER_NAME
          })
    time.sleep(5)
    run('docker cp %s db:%s' % ('/home/ec2-user/%s' % CONF_FILE_NAME, '/var/lib/postgresql/data/postgresql.conf'))
    run('docker restart db')

@roles('signingServer')
def startSigningServer(build):
    run('docker run \
        --log-opt max-size=100m \
        --log-opt max-file=5 \
        --detach \
        -p %(port)s:8090 \
        -e MQ_HOST_PORT_5672_TCP_ADDR=%(rabbitHost)s \
        -e MQ_HOST_PORT_5672_TCP_PORT=%(rabbitPort)s \
        -e METADB_HOST=%(dbHost)s \
        -e METADB_PORT=%(dbPort)s \
        --name sign-server \
        %(dockerRepo)s/signing-server:%(build)s' \
            % {"build": build,
               "rabbitHost": env.rabbitHostPrivate,
               "rabbitPort": env.RABBIT_PORT,
               "port": env.SIGNING_SERVER_PORT,
               'dbHost': env.dbHostPrivate,
               'dbPort': env.DB_PORT,
               'dockerRepo': env.dockerRepo
               })

